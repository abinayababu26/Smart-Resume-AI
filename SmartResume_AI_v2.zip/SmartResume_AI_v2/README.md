# SmartResume AI — Resume Screening, Skill Gap Analysis & Job Recommendation

This version upgrades the original resume classifier into a final-year Data Science project with:

- PDF/DOCX/TXT resume upload
- NLP preprocessing + TF-IDF classification
- Duplicate-aware model evaluation
- Skill extraction
- Resume-to-job matching
- Matched and missing skill analysis
- Job-role recommendations
- Skill-gap analysis
- Streamlit dashboard
- CSV export

## Important dataset note
The supplied dataset contains 962 rows but only 166 unique resume texts. The training script removes exact duplicate resume texts **before evaluation** to reduce train/test leakage.

Do not report the original 99.5% accuracy as the final project result without explaining this leakage issue. Run the new training script and report the new test accuracy, macro F1 and cross-validation macro F1 from `reports/metrics.json`.

## Setup

```bash
pip install -r requirements.txt
python train.py --data data/resumes.csv
streamlit run app.py
```

## Main architecture

```text
Resume
  ↓
PDF/DOCX/TXT Extraction
  ↓
NLP Preprocessing
  ↓
TF-IDF + ML Classification
  ↓
Skill Extraction
  ↓
Job Matching
  ↓
Job Recommendation
  ↓
Skill Gap Analysis
  ↓
Streamlit Dashboard
```

## Project structure

```text
SmartResume_AI_v2/
├── app.py
├── train.py
├── predict.py
├── preprocessing.py
├── extract_text.py
├── skill_extractor.py
├── job_matching.py
├── requirements.txt
├── data/
│   ├── resumes.csv
│   ├── skills.csv
│   └── jobs.csv
├── models/
└── reports/
```

## Next advanced upgrade
After the TF-IDF version is stable, add Sentence Transformers for semantic resume-to-job similarity. Keep TF-IDF as a baseline for your academic comparison.
