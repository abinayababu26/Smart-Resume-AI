import re
import string

try:
    import nltk
    from nltk.corpus import stopwords
    from nltk.stem import WordNetLemmatizer
    from nltk.tokenize import word_tokenize
    from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

    _NLTK_READY = False
    try:
        nltk.data.find("corpora/stopwords")
        nltk.data.find("corpora/wordnet")
        nltk.data.find("tokenizers/punkt")
        _NLTK_READY = True
    except LookupError:
        _NLTK_READY = False

    if _NLTK_READY:
        STOPWORDS = set(stopwords.words("english"))
        LEMMATIZER = WordNetLemmatizer()
    else:
        STOPWORDS = set(ENGLISH_STOP_WORDS)
        LEMMATIZER = None
except Exception:
    from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
    STOPWORDS = set(ENGLISH_STOP_WORDS)
    LEMMATIZER = None

URL_PATTERN = re.compile(r"https?://\S+|www\.\S+", re.I)
EMAIL_PATTERN = re.compile(r"\S+@\S+")
PHONE_PATTERN = re.compile(r"(\+?\d[\d\-\s()]{7,}\d)")
NON_ALPHA_PATTERN = re.compile(r"[^a-zA-Z\s]")
MULTI_SPACE_PATTERN = re.compile(r"\s+")


def clean_resume_text(text: str) -> str:
    if not isinstance(text, str):
        return ""

    text = text.lower()
    text = URL_PATTERN.sub(" ", text)
    text = EMAIL_PATTERN.sub(" ", text)
    text = PHONE_PATTERN.sub(" ", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = NON_ALPHA_PATTERN.sub(" ", text)
    text = MULTI_SPACE_PATTERN.sub(" ", text).strip()

    if LEMMATIZER is not None:
        try:
            tokens = word_tokenize(text)
            tokens = [t for t in tokens if t not in STOPWORDS and len(t) > 2]
            tokens = [LEMMATIZER.lemmatize(t) for t in tokens]
        except LookupError:
            tokens = [t for t in text.split() if t not in STOPWORDS and len(t) > 2]
    else:
        tokens = [t for t in text.split() if t not in STOPWORDS and len(t) > 2]

    return " ".join(tokens)


if __name__ == "__main__":
    sample = "Experienced in Python, Machine Learning, and Data Analysis."
    print(clean_resume_text(sample))
