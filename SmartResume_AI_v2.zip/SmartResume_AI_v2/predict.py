import argparse
import glob
import os

import joblib
import numpy as np
import pandas as pd

from extract_text import extract_text_from_file
from preprocessing import clean_resume_text

MODEL_PATH = "models/resume_screening_pipeline.joblib"
ENCODER_PATH = "models/label_encoder.joblib"


def load_artifacts(model_path=MODEL_PATH, encoder_path=ENCODER_PATH):
    if not os.path.exists(model_path) or not os.path.exists(encoder_path):
        raise FileNotFoundError(
            "Trained model artifacts not found. Run `python train.py` first."
        )
    pipeline = joblib.load(model_path)
    label_encoder = joblib.load(encoder_path)
    return pipeline, label_encoder


def predict_category(text: str, pipeline, label_encoder, top_k: int = 3):
    """
    Returns the top_k predicted categories with confidence scores for a
    single resume text.
    """
    cleaned = clean_resume_text(text)
    clf = pipeline.named_steps["clf"]
    vectorizer = pipeline.named_steps["tfidf"]
    vec = vectorizer.transform([cleaned])

    if hasattr(clf, "predict_proba"):
        probs = clf.predict_proba(vec)[0]
    elif hasattr(clf, "decision_function"):
        # LinearSVC has no predict_proba; convert decision scores to
        # pseudo-probabilities via softmax for a comparable confidence score
        scores = clf.decision_function(vec)[0]
        exp_scores = np.exp(scores - np.max(scores))
        probs = exp_scores / exp_scores.sum()
    else:
        pred_idx = clf.predict(vec)[0]
        return [(label_encoder.inverse_transform([pred_idx])[0], 1.0)]

    top_indices = np.argsort(probs)[::-1][:top_k]
    results = [
        (label_encoder.inverse_transform([idx])[0], float(probs[idx]))
        for idx in top_indices
    ]
    return results


def predict_single(text=None, file=None, pipeline=None, label_encoder=None):
    if file:
        text = extract_text_from_file(file)
    if not text or not text.strip():
        raise ValueError("No resume text provided or extracted.")
    return predict_category(text, pipeline, label_encoder)


def predict_folder(folder_path, pipeline, label_encoder):
    supported_ext = ("*.pdf", "*.docx", "*.txt")
    files = []
    for ext in supported_ext:
        files.extend(glob.glob(os.path.join(folder_path, ext)))

    rows = []
    for f in sorted(files):
        try:
            text = extract_text_from_file(f)
            results = predict_category(text, pipeline, label_encoder)
            top_category, top_conf = results[0]
            rows.append(
                {
                    "File": os.path.basename(f),
                    "Predicted_Category": top_category,
                    "Confidence": round(top_conf, 4),
                    "Top_3_Predictions": "; ".join(
                        f"{c} ({conf:.2%})" for c, conf in results
                    ),
                }
            )
        except Exception as e:
            rows.append(
                {
                    "File": os.path.basename(f),
                    "Predicted_Category": "ERROR",
                    "Confidence": None,
                    "Top_3_Predictions": str(e),
                }
            )
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description="Predict resume job category.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--text", help="Raw resume text to classify")
    group.add_argument("--file", help="Path to a single resume file (.pdf/.docx/.txt)")
    group.add_argument("--folder", help="Path to a folder of resumes to batch classify")
    parser.add_argument("--out", default="predictions.csv", help="Output CSV for --folder mode")
    args = parser.parse_args()

    pipeline, label_encoder = load_artifacts()

    if args.folder:
        df = predict_folder(args.folder, pipeline, label_encoder)
        df.to_csv(args.out, index=False)
        print(df.to_string(index=False))
        print(f"\nSaved batch predictions to {args.out}")
    else:
        results = predict_single(
            text=args.text, file=args.file, pipeline=pipeline, label_encoder=label_encoder
        )
        print("\nTop predicted categories:")
        for category, confidence in results:
            print(f"  {category:<25} {confidence:.2%}")


if __name__ == "__main__":
    main()
