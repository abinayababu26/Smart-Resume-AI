from pathlib import Path
import re
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

BASE_DIR = Path(__file__).resolve().parent
JOBS_PATH = BASE_DIR / "data" / "jobs.csv"


def load_jobs(path=JOBS_PATH):
    return pd.read_csv(path).fillna("")


def _normalise_skills(skills):
    return {str(s).strip().lower() for s in skills if str(s).strip()}


def _contains_skill(text, skill):
    escaped = re.escape(skill.lower())
    if re.search(r"[a-zA-Z0-9]$", skill):
        return bool(re.search(rf"(?<![a-zA-Z0-9]){escaped}(?![a-zA-Z0-9])", text.lower()))
    return bool(re.search(escaped, text.lower()))


def job_match(resume_text, job_description, resume_skills=None, job_skills=None):
    """Return an interpretable 0-100 match score plus matched/missing skills.

    Score combines semantic-ish TF-IDF cosine similarity (60%) and skill coverage
    (40%). This is a screening aid, not a hiring decision.
    """
    resume_text = resume_text or ""
    job_description = job_description or ""
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), stop_words="english")
    try:
        matrix = vectorizer.fit_transform([resume_text, job_description])
        similarity = float(cosine_similarity(matrix[0:1], matrix[1:2])[0, 0])
    except ValueError:
        similarity = 0.0

    resume_set = _normalise_skills(resume_skills or [])
    job_set = _normalise_skills(job_skills or [])
    if job_set:
        matched = sorted(resume_set & job_set)
        missing = sorted(job_set - resume_set)
        skill_coverage = len(matched) / len(job_set)
    else:
        matched = []
        missing = []
        skill_coverage = 0.0

    score = round((0.60 * similarity + 0.40 * skill_coverage) * 100, 1)
    return {
        "score": score,
        "similarity": round(similarity * 100, 1),
        "skill_coverage": round(skill_coverage * 100, 1),
        "matched_skills": matched,
        "missing_skills": missing,
    }


def recommend_jobs(resume_text, resume_skills, jobs_df=None, top_k=5):
    jobs_df = jobs_df if jobs_df is not None else load_jobs()
    results = []
    for _, row in jobs_df.iterrows():
        required = [s.strip() for s in str(row["skills"]).split("|") if s.strip()]
        result = job_match(resume_text, row["description"], resume_skills, required)
        results.append({
            "Job Role": row["role"],
            "Match Score": result["score"],
            "Matched Skills": ", ".join(result["matched_skills"]),
            "Missing Skills": ", ".join(result["missing_skills"]),
        })
    return pd.DataFrame(results).sort_values("Match Score", ascending=False).head(top_k).reset_index(drop=True)
