import os
import tempfile
from pathlib import Path

import pandas as pd
import streamlit as st

from extract_text import extract_text_from_file
from job_matching import load_jobs, recommend_jobs, job_match
from predict import load_artifacts, predict_category
from skill_extractor import load_skills, extract_skills

BASE_DIR = Path(__file__).resolve().parent
st.set_page_config(page_title="SmartResume AI", page_icon="📄", layout="wide")

st.markdown("""
<style>
[data-testid="stAppViewContainer"] { background: linear-gradient(135deg,#f8fafc 0%,#dbeafe 48%,#fce7f3 100%); }
[data-testid="stSidebar"] { background: rgba(255,255,255,.94); }
.block-container { padding-top: 2rem; }
.metric-card { background: rgba(255,255,255,.78); border:1px solid rgba(148,163,184,.25); border-radius:18px; padding:18px; }
.small-note { color:#475569; font-size:.9rem; }
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def artifacts():
    return load_artifacts(
        str(BASE_DIR / "models" / "resume_screening_pipeline.joblib"),
        str(BASE_DIR / "models" / "label_encoder.joblib"),
    )

@st.cache_data
def data_assets():
    return load_skills(), load_jobs()

try:
    pipeline, label_encoder = artifacts()
    skills_df, jobs_df = data_assets()
except FileNotFoundError:
    st.error("Model files are missing. Run: python train.py")
    st.stop()

st.title("📄 SmartResume AI")
st.caption("NLP-based resume screening, skill-gap analysis and job recommendation")
st.info("This application provides model-based screening and recommendations. It should support human review, not replace it.")

with st.sidebar:
    st.header("System")
    st.write(f"**{len(label_encoder.classes_)}** job categories")
    st.write(f"**{len(skills_df)}** tracked skills")
    st.write(f"**{len(jobs_df)}** recommendation roles")
    st.divider()
    st.markdown("**Pipeline**")
    st.write("Resume → NLP → Classification → Skills → Job Matching → Recommendations")

# Session resume state
if "resume_text" not in st.session_state:
    st.session_state.resume_text = ""
if "resume_name" not in st.session_state:
    st.session_state.resume_name = ""

st.subheader("1. Upload Resume")
uploaded = st.file_uploader("PDF, DOCX or TXT", type=["pdf", "docx", "txt"])
manual = st.text_area("Or paste resume text", height=180)

if uploaded:
    suffix = os.path.splitext(uploaded.name)[1]
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded.getbuffer())
        tmp_path = tmp.name
    try:
        st.session_state.resume_text = extract_text_from_file(tmp_path)
        st.session_state.resume_name = uploaded.name
    finally:
        os.unlink(tmp_path)
elif manual.strip():
    st.session_state.resume_text = manual
    st.session_state.resume_name = "Pasted resume"

resume_text = st.session_state.resume_text

if not resume_text.strip():
    st.info("Upload a resume or paste resume text to begin.")
    st.stop()

skills = extract_skills(resume_text, skills_df)
skill_names = [x["skill"] for x in skills]

st.success(f"Resume loaded: {st.session_state.resume_name or 'Resume'}")

# Top analysis
predictions = predict_category(resume_text, pipeline, label_encoder, top_k=3)
top_role, top_prob = predictions[0]

c1, c2, c3, c4 = st.columns(4)
c1.metric("Predicted Category", top_role)
c2.metric("Model Probability", f"{top_prob:.1%}")
c3.metric("Skills Detected", len(skill_names))
c4.metric("Text Length", f"{len(resume_text.split()):,} words")

st.divider()
tab1, tab2, tab3, tab4, tab5 = st.tabs(["🔎 Screening", "🎯 Job Matching", "💼 Recommendations", "📚 Skill Gap", "👥 Batch Screening"])

with tab1:
    st.subheader("Resume Screening")
    col1, col2 = st.columns([1, 1])
    with col1:
        st.markdown("### Top Predictions")
        for role, prob in predictions:
            st.progress(min(float(prob), 1.0), text=f"{role} — {prob:.1%}")
    with col2:
        st.markdown("### Detected Skills")
        if skill_names:
            st.write(" · ".join(skill_names))
        else:
            st.warning("No skills from the current skill dictionary were detected.")
    with st.expander("View extracted text"):
        st.text(resume_text[:8000])

with tab2:
    st.subheader("Match Resume Against a Job Description")
    mode = st.radio("Job description source", ["Role Library", "Custom Job Description"], horizontal=True)
    if mode == "Role Library":
        selected_role = st.selectbox("Choose a role", jobs_df["role"].tolist())
        row = jobs_df[jobs_df["role"] == selected_role].iloc[0]
        jd_text = row["description"]
        required_skills = str(row["skills"]).split("|")
    else:
        jd_text = st.text_area("Paste the job description", height=180, placeholder="Example: Looking for a Data Scientist with Python, SQL, machine learning and Power BI...")
        required_skills = [x["skill"] for x in extract_skills(jd_text, skills_df)] if jd_text.strip() else []

    if jd_text.strip():
        result = job_match(resume_text, jd_text, skill_names, required_skills)
        m1, m2, m3 = st.columns(3)
        m1.metric("Overall Match", f"{result['score']:.1f}%")
        m2.metric("Text Similarity", f"{result['similarity']:.1f}%")
        m3.metric("Skill Coverage", f"{result['skill_coverage']:.1f}%")
        st.markdown("### Matched Skills")
        st.success(", ".join(result["matched_skills"]) if result["matched_skills"] else "No required skills matched yet.")
        st.markdown("### Missing / Gap Skills")
        st.warning(", ".join(result["missing_skills"]) if result["missing_skills"] else "No missing skills from the current role dictionary.")
        st.markdown("### Job Description")
        st.write(jd_text)
    else:
        st.info("Choose a role or paste a job description to calculate the match.")

with tab3:
    st.subheader("Recommended Job Roles")
    recs = recommend_jobs(resume_text, skill_names, jobs_df, top_k=8)
    st.dataframe(recs, use_container_width=True, hide_index=True)
    st.download_button("⬇️ Download recommendations", recs.to_csv(index=False).encode("utf-8"), "job_recommendations.csv", "text/csv")

with tab4:
    st.subheader("Skill Gap Analysis")
    target = st.selectbox("Target role", jobs_df["role"].tolist(), key="target_role")
    target_row = jobs_df[jobs_df["role"] == target].iloc[0]
    required = [s.strip() for s in str(target_row["skills"]).split("|") if s.strip()]
    matched = [s for s in required if s.lower() in {x.lower() for x in skill_names}]
    missing = [s for s in required if s.lower() not in {x.lower() for x in skill_names}]
    a, b = st.columns(2)
    with a:
        st.markdown("### Already Detected")
        for s in matched:
            st.write(f"✅ {s}")
    with b:
        st.markdown("### Skills to Develop")
        for s in missing:
            st.write(f"🔸 {s}")
    if missing:
        st.info("Suggested roadmap: strengthen the missing role-specific skills through projects, coursework and practice, then update the resume with measurable evidence.")

with tab5:
    st.subheader("Recruiter Batch Screening")
    batch_files = st.file_uploader("Upload multiple resumes", type=["pdf", "docx", "txt"], accept_multiple_files=True, key="batch_upload")
    if batch_files:
        rows = []
        for batch_file in batch_files:
            suffix = os.path.splitext(batch_file.name)[1]
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(batch_file.getbuffer())
                batch_path = tmp.name
            try:
                batch_text = extract_text_from_file(batch_path)
                batch_predictions = predict_category(batch_text, pipeline, label_encoder, top_k=3)
                batch_skills = [x["skill"] for x in extract_skills(batch_text, skills_df)]
                rows.append({
                    "Resume": batch_file.name,
                    "Predicted Role": batch_predictions[0][0],
                    "Model Probability": f"{batch_predictions[0][1]:.1%}",
                    "Skills Detected": len(batch_skills),
                    "Top 3": ", ".join(f"{r} ({p:.1%})" for r, p in batch_predictions),
                })
            except Exception as exc:
                rows.append({"Resume": batch_file.name, "Predicted Role": "ERROR", "Model Probability": "-", "Skills Detected": 0, "Top 3": str(exc)})
            finally:
                os.unlink(batch_path)
        batch_df = pd.DataFrame(rows)
        st.dataframe(batch_df, use_container_width=True, hide_index=True)
        st.download_button("⬇️ Download screening CSV", batch_df.to_csv(index=False).encode("utf-8"), "batch_screening_results.csv", "text/csv")
    else:
        st.info("Upload multiple resumes to screen them together.")

st.divider()
st.caption("SmartResume AI — screening assistance only. Final recruitment decisions should include human review and job-specific criteria.")
