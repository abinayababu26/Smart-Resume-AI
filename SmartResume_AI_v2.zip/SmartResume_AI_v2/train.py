import argparse
import json
import warnings
from pathlib import Path

import joblib
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import StratifiedKFold, GridSearchCV, train_test_split, cross_val_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder
from sklearn.svm import LinearSVC

from preprocessing import clean_resume_text

warnings.filterwarnings("ignore")


def load_data(csv_path):
    df = pd.read_csv(csv_path)
    required = {"Resume_Text", "Category"}
    if not required.issubset(df.columns):
        raise ValueError(f"CSV must contain {required}; found {list(df.columns)}")
    df = df.dropna(subset=["Resume_Text", "Category"]).copy()
    before = len(df)
    df["Resume_Text"] = df["Resume_Text"].astype(str).str.strip()
    df = df[df["Resume_Text"].ne("")]
    after_empty = len(df)
    df = df.drop_duplicates(subset=["Resume_Text"]).reset_index(drop=True)
    print(f"Original rows: {before}")
    print(f"After removing empty resumes: {after_empty}")
    print(f"Unique resumes used for evaluation: {len(df)}")
    print(f"Exact duplicates removed: {after_empty - len(df)}")
    return df


def main(args):
    Path(args.model_out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.encoder_out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.metrics_out).parent.mkdir(parents=True, exist_ok=True)

    df = load_data(args.data)
    print(f"Categories: {df['Category'].nunique()}")
    df["Cleaned_Text"] = df["Resume_Text"].apply(clean_resume_text)

    encoder = LabelEncoder()
    y = encoder.fit_transform(df["Category"])
    X = df["Cleaned_Text"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    vectorizer = TfidfVectorizer(max_features=8000, ngram_range=(1, 2), min_df=1, max_df=0.95, sublinear_tf=True)
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

    candidates = {
        "Naive Bayes": MultinomialNB(),
        "Logistic Regression": LogisticRegression(max_iter=2000, class_weight="balanced"),
        "Linear SVM": LinearSVC(class_weight="balanced"),
    }

    baseline_scores = {}
    trained = {}
    for name, model in candidates.items():
        model.fit(X_train_vec, y_train)
        pred = model.predict(X_test_vec)
        score = f1_score(y_test, pred, average="macro")
        baseline_scores[name] = score
        trained[name] = model
        print(f"{name}: accuracy={accuracy_score(y_test, pred):.4f}, macro_f1={score:.4f}")

    best_name = max(baseline_scores, key=baseline_scores.get)
    best_model = trained[best_name]

    if best_name == "Logistic Regression":
        grid = GridSearchCV(
            LogisticRegression(max_iter=2000, class_weight="balanced"),
            {"C": [0.1, 0.5, 1, 2, 5, 10]},
            cv=3, scoring="f1_macro", n_jobs=-1,
        )
        grid.fit(X_train_vec, y_train)
        best_model = grid.best_estimator_
        print("Best params:", grid.best_params_)
    elif best_name == "Linear SVM":
        grid = GridSearchCV(
            LinearSVC(class_weight="balanced"),
            {"C": [0.1, 0.5, 1, 2, 5, 10]},
            cv=3, scoring="f1_macro", n_jobs=-1,
        )
        grid.fit(X_train_vec, y_train)
        best_model = grid.best_estimator_
        print("Best params:", grid.best_params_)

    if best_name == "Linear SVM":
        final_clf = CalibratedClassifierCV(best_model, cv=3, method="sigmoid")
        final_clf.fit(X_train_vec, y_train)
    else:
        final_clf = best_model

    pred = final_clf.predict(X_test_vec)
    acc = accuracy_score(y_test, pred)
    macro_f1 = f1_score(y_test, pred, average="macro")
    weighted_f1 = f1_score(y_test, pred, average="weighted")
    report = classification_report(y_test, pred, target_names=encoder.classes_, output_dict=True, zero_division=0)
    cm = confusion_matrix(y_test, pred).tolist()

    # 3-fold CV on the deduplicated dataset using the selected model family.
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    cv_pipe = Pipeline([
        ("tfidf", TfidfVectorizer(max_features=8000, ngram_range=(1, 2), min_df=1, max_df=0.95, sublinear_tf=True)),
        ("clf", LogisticRegression(max_iter=2000, class_weight="balanced") if best_name == "Logistic Regression" else LinearSVC(class_weight="balanced")),
    ])
    cv_scores = cross_val_score(cv_pipe, X, y, cv=cv, scoring="f1_macro", n_jobs=-1)

    pipeline = Pipeline([("tfidf", vectorizer), ("clf", final_clf)])
    joblib.dump(pipeline, args.model_out)
    joblib.dump(encoder, args.encoder_out)

    metrics = {
        "original_rows": int(before := pd.read_csv(args.data).shape[0]),
        "unique_rows_used": int(len(df)),
        "duplicates_removed": int(before - len(df)),
        "categories": int(df["Category"].nunique()),
        "best_model": best_name,
        "test_accuracy": round(float(acc), 4),
        "test_macro_f1": round(float(macro_f1), 4),
        "test_weighted_f1": round(float(weighted_f1), 4),
        "cv_macro_f1_mean": round(float(cv_scores.mean()), 4),
        "cv_macro_f1_std": round(float(cv_scores.std()), 4),
        "baseline_macro_f1": {k: round(float(v), 4) for k, v in baseline_scores.items()},
        "classification_report": report,
        "confusion_matrix": cm,
        "classes": encoder.classes_.tolist(),
    }
    with open(args.metrics_out, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    print("\nFinal evaluation")
    print(f"Accuracy: {acc:.4f}")
    print(f"Macro F1: {macro_f1:.4f}")
    print(f"Weighted F1: {weighted_f1:.4f}")
    print(f"3-fold CV Macro F1: {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
    print(f"Saved: {args.model_out}")
    print(f"Saved: {args.encoder_out}")
    print(f"Saved: {args.metrics_out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/resumes.csv")
    parser.add_argument("--model_out", default="models/resume_screening_pipeline.joblib")
    parser.add_argument("--encoder_out", default="models/label_encoder.joblib")
    parser.add_argument("--metrics_out", default="reports/metrics.json")
    args = parser.parse_args()
    main(args)
