import re
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
SKILLS_PATH = BASE_DIR / "data" / "skills.csv"


def load_skills(path=SKILLS_PATH):
    df = pd.read_csv(path).dropna(subset=["skill", "category"])
    return df


def _pattern(skill: str) -> re.Pattern:
    # Allow punctuation-heavy skills such as C++, C#, .NET, Node.js.
    escaped = re.escape(skill.lower().strip())
    if re.search(r"[a-zA-Z0-9]$", skill):
        return re.compile(rf"(?<![a-zA-Z0-9]){escaped}(?![a-zA-Z0-9])", re.I)
    return re.compile(escaped, re.I)


def extract_skills(text: str, skills_df=None):
    if not isinstance(text, str):
        return []
    skills_df = skills_df if skills_df is not None else load_skills()
    found = []
    for _, row in skills_df.sort_values("skill", key=lambda s: s.str.len(), ascending=False).iterrows():
        skill = str(row["skill"]).strip()
        if skill and _pattern(skill).search(text):
            found.append({"skill": skill, "category": row["category"]})
    # De-duplicate while preserving order.
    seen = set()
    result = []
    for item in found:
        key = item["skill"].lower()
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def skill_names(text: str, skills_df=None):
    return [x["skill"] for x in extract_skills(text, skills_df)]
